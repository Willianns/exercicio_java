/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

/**
 *
 * @author ASUS
 */
public class MestreJedi extends Jedi implements Raios {

    public MestreJedi(String nome) {
        super(100, 200, nome);  // Força 100, Vida 200 para um MestreJedi
    }

    @Override
    public void usarRaio() {
        System.out.println(nome + " usa raios com " + (força + forçaExtra) + " de força!");
    }
}
