/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

/**
 *
 * @author ASUS
 */
public abstract class Sith extends Força{
    Sith(int força, int vida, String nome){
        super(força, vida, nome);
        this.genero = "Sith";
    }
}
