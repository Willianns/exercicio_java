/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

/**
 *
 * @author ASUS
 */
public class Padawan extends Jedi{
    Padawan(String nome){
        super(20, 100, nome); // Força 20, Vida 100 para um Padawan
    }
}
