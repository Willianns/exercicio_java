/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho1;

/**
 *
 * @author ASUS
 */
public class Trabalho1 {
    public static void main(String[] args) {
        Padawan padawan = new Padawan("Anakin");
        MestreJedi mestreJedi = new MestreJedi("Yoda");
        Aprendiz aprendiz = new Aprendiz("Darth Maul");
        MestreSith mestreSith = new MestreSith("Palpatine");

        // Exemplo de ataque
        padawan.atacar(aprendiz);      // Anakin ataca Darth Maul
        mestreJedi.atacar(mestreSith);  // Yoda ataca Palpatine
    }
}