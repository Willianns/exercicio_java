/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

/**
 *
 * @author ASUS
 */
public abstract class Força {
    int força;
    private int vida;
    String genero;
    String nome;
    
    Força(int força, int vida, String nome){
    this.força = força;
    this.vida = vida;
    this.nome = nome;
}

    public void setGenero(String genero){
        this.genero = genero;

}   

    public void atacar(Força alvo){
        if(alvo.vida > 0){
            System.out.println(nome + " ataca " + alvo.nome + " com " + força + " de força "); 
            alvo.vida -= this.força;
            if(alvo.vida <= 0) {
                alvo.vida = 0;
                System.out.println(" Fui derrotado ");
            }else {
                System.out.println(alvo.nome + " agora tem " + alvo.vida + " de vida ");
            }
        }else {
            System.out.println(alvo.nome + " Ja foi derrotado ");
        }
    }
}
