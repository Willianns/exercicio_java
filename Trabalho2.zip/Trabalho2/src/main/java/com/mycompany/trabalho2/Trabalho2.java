/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho2;

/**
 *
 * @author ASUS
 */
import java.util.Scanner;
public class Trabalho2 {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("calculadora - digite '.' para sair");
            while (true) {
                System.out.print("Digite o operador (+, -, /, *): ");
                String operador = scanner.next();
                
                if (operador.equals(".")) {
                    System.out.println("Encerrando o programa...");
                    break;
                }
                System.out.print("Digite o primeiro número: ");
                int num1 = scanner.nextInt();
                System.out.print("Digite o segundo número: ");
                int num2 = scanner.nextInt();
                
                Calculadora calc = new Calculadora(num1, num2);
                
                switch (operador) {
                    case "+" -> System.out.println("Resultado: " + calc.some());
                    case "-" -> System.out.println("Resultado: " + calc.subtraia());
                    case "/" -> System.out.println("Resultado: " + calc.divida());
                    case "*" -> System.out.println("Resultado: " + calc.multiplique());
                    default -> System.out.println("Operador inválido.");
                }
            }
        }
    }
}


