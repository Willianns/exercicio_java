/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho3;

/**
 *
 * @author ASUS
 */
import java.util.Random;
import java.util.Scanner;
abstract class Personagem implements Jogador {
    protected int vida;
    protected int forca;

    public Personagem(int vida, int forca) {
        this.vida = vida;
        this.forca = forca;
    }

    public int getVida() {
        return vida;
    }

    public boolean estaVivo() {
        return vida > 0;
    }

    // Método abstrato que deve ser implementado por subclasses
    public abstract void atacar(Personagem p);

    // Implementação do método curar (gera um valor aleatório de cura)
    public void curar() {
        Random random = new Random();
        int cura = random.nextInt(20) + 1;
        vida += cura;
        System.out.println(getClass().getSimpleName() + " curou " + cura + " pontos de vida.");
    }
}