/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho3;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Trabalho3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        Personagem jogador = new Guerreiro(100, 20);
        Personagem computador = new Mago(100, 15);

        System.out.println("Começa a batalha!");

        while (jogador.estaVivo() && computador.estaVivo()) {
            System.out.print("Escolha sua ação (1 - Atacar, 2 - Curar): ");
            int escolha = scanner.nextInt();

            if (escolha == 1) {
                jogador.atacar(computador);
            } else if (escolha == 2) {
                jogador.curar();
            } else {
                System.out.println("Ação inválida!");
                continue;
            }

            if (computador.estaVivo()) {
                int acaoComputador = random.nextInt(2) + 1;
                if (acaoComputador == 1) {
                    computador.atacar(jogador);
                } else {
                    computador.curar();
                }
            }

            System.out.println("Vida do Jogador: " + jogador.getVida());
            System.out.println("Vida do Computador: " + computador.getVida());
        }

        if (jogador.estaVivo()) {
            System.out.println("Você venceu a batalha!");
        } else {
            System.out.println("O computador venceu a batalha!");
        }

        scanner.close();
    }
}
